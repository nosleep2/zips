import os, xbmc, xbmcaddon

#########################################################
### User Edit Variables #################################
#########################################################
ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
ADDONTITLE     = '[COLORghostwhite][B]No-Sleep Wizard[/B][/COLOR]'
EXCLUDES       = [ADDON_ID, 'repository.no-sleep']
# Text File with build info in it.
BUILDFILE      = 'https://pastebin.com/raw/aZTUw2xv'
# How often you would list it to check for build updates in days
# 0 being every startup of kodi
UPDATECHECK    = 0
# Text File with apk info in it.
APKFILE        = 'https://pastebin.com/raw/SsMsZUDM'
# Text File with Youtube Videos urls.  Leave as 'http://' to ignore
YOUTUBETITLE   = 'No-Sleep Help '
YOUTUBEFILE    = 'https://pastebin.com/raw/tFHvm6Wz'
# Text File for addon installer.  Leave as 'http://' to ignore
ADDONFILE      = 'https://pastebin.com/raw/QvWv8zKt'
# Text File for advanced settings.  Leave as 'http://' to ignore
ADVANCEDFILE   = 'http://'

# Dont need to edit just here for icons stored locally
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')

#########################################################
### THEMING MENU ITEMS ##################################
#########################################################
# If you want to use locally stored icons the place them in the Resources/Art/
# folder of the wizard then use os.path.join(ART, 'imagename.png')
# do not place quotes around os.path.join
# Example:  ICONMAINT     = os.path.join(ART, 'mainticon.png')
#           ICONSETTINGS  = 'http://aftermathwizard.net/repo/wizard/settings.png'
# Leave as http:// for default icon
ICONBUILDS     = 'https://archive.org/download/Builds_20180411/Builds.jpg'
ICONMAINT      = 'https://archive.org/download/Maintenance_201804/Maintenance.jpg'
ICONAPK        = 'https://archive.org/download/firetvguru1_gmail_Apk/Apk.jpg'
ICONADDONS     = 'https://archive.org/download/Addon_201804/Addon.jpg'
ICONYOUTUBE    = 'https://archive.org/download/Youtube_20180411/Youtube.jpg'
ICONSAVE       = 'https://archive.org/download/Savedata_201804/Savedata.jpg'
ICONTRAKT      = 'https://archive.org/download/Trakt_201804/Trakt.jpg'
ICONREAL       = 'https://archive.org/download/Realdebrid_201804/Realdebrid.jpg'
ICONLOGIN      = 'https://archive.org/download/Login_201804/Login.jpg'
ICONCONTACT    = 'http://'
ICONSETTINGS   = 'https://archive.org/download/Settings_201804/Settings.jpg'
# Hide the ====== seperators 'Yes' or 'No'
HIDESPACERS    = 'No'
# Character used in seperator
SPACER         = '~'

# You can edit these however you want, just make sure that you have a %s in each of the
# THEME's so it grabs the text from the menu item
COLOR1         = 'chartreuse'
COLOR2         = 'white'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR1+'][B]*No-Sleep*[/B][/COLOR][COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required
THEME4         = '[COLOR '+COLOR1+']Current Build:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'

# Message for Contact Page
# Enable 'Contact' menu item 'Yes' hide or 'No' dont hide
HIDECONTACT    = 'Yes'
# You can add \n to do line breaks
CONTACT        = 'Thank you for choosing Aftermath Wizard.\r\n\r\nContact us on facebook at http://facebook.com'
#Images used for the contact window.  http:// for default icon and fanart
CONTACTICON    = 'http://'
CONTACTFANART  = 'http://'
#########################################################

#########################################################
### AUTO UPDATE #########################################
########## FOR THOSE WITH NO REPO #######################
# Enable Auto Update 'Yes' or 'No'
AUTOUPDATE     = 'No'
# Url to wizard version
WIZARDFILE     = ''
#########################################################

#########################################################
### AUTO INSTALL ########################################
########## REPO IF NOT INSTALLED ########################
# Enable Auto Install 'Yes' or 'No'
AUTOINSTALL    = 'Yes'
# Addon ID for the repository
REPOID         = 'repository.no-sleep'
# Url to Addons.xml file in your repo folder(this is so we can get the latest version)
REPOADDONXML   = 'https://raw.githubusercontent.com/nosleep2/repo/master/addons.xml'
# Url to folder zip is located in
REPOZIPURL     = 'https://raw.githubusercontent.com/nosleep2/zips/master/addons/'
#########################################################

#########################################################
### NOTIFICATION WINDOW##################################
#########################################################
# Enable Notification screen Yes or No
ENABLE         = 'Yes'
# Url to notification file
NOTIFICATION   = 'https://pastebin.com/raw/0QAG462Y'
# Use either 'Text' or 'Image'
HEADERTYPE     = 'Text'
HEADERMESSAGE  = 'No-Sleep Messages'
# url to image if using Image 424x180
HEADERIMAGE    = ''
# Background for Notification Window
BACKGROUND     = 'https://archive.org/download/Webp.netCompressImage_201804/Webp.net-compress-image.jpg'
#########################################################